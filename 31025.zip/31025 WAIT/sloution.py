n , k = input().split(' ')
n , k = int(n) , int(k)
if(n==0 or k==0):
	print(n)
else:
	number = float(n)
	for i in range(k):
		number = number / 2
	if int(number) == float(number):
		print(int(number))
	else:
		if number > 0:
			print(int(number))
		if number < 0:
			print(int(number) - 1)
