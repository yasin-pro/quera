#include <stdio.h>

int main()
{


	int x1,y1,x2,y2;

	scanf("%d%d%d%d" , &x1 , &y1 , &x2 , &y2);

	if (y1 == y2)
	{

		printf("%s","Horizontal");
	}

	if (x1 == x2)
	{
		printf("%s" , "Vertical");
	}

	if (x1!=x2&&y1!=y2)
	{
		printf("%s" , "Try again");
	}

	return 0;
}