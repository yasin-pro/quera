#include <stdio.h>

int main(){

	int a , b , c ;

	scanf("%d%d%d" , &a , &b , &c);

	a = a * a;
	b = b * b;
	c = c * c;

	if((a + b) == c)
	{
		printf("%s" , "Yes");
	}else if((c + b) == a)
	{
		printf("%s" , "Yes");
	}else if((c + a) == b)
	{
		printf("%s" , "Yes");
	}
	else
	{
		printf("%s" , "No");
	}

	return 0;
}
