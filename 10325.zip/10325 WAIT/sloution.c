#include <stdio.h>


// FOR FIND NUMBER OF ROW REVERSE
int findRow(int x)
{
	int tempTwo = 0;
	while(x + tempTwo != 11)
	{
		tempTwo = tempTwo + 1;
	}
	return tempTwo;
}

// FOR FIND NUMBER OF CHAIR REVERSE
int findChair(int x)
{
	int tempTwo = 0;
	while(x + tempTwo != 21)
	{
		tempTwo = tempTwo + 1;
	}
	return tempTwo;
}


// THIS IS MAIN FUNCTION
int main()
{

	int r,c,temp;

	scanf("%d%d" , &r , &c);

	if(1 <= c && c <= 10)
	{

		printf("%s " , "Right");
		printf("%d " , findRow(r));
		printf("%d" , c);


	}else
	{

		printf("%s " , "Left");
		printf("%d " , findRow(r));
		printf("%d" , findChair(c));

	}

	return 0;
}


