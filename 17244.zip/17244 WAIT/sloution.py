
k = int(input())
minute = 0
for i in range(1 , k+1):
    minute += i
print(minute)