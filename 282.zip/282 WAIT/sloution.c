

#include <stdio.h>

// Main Function
int main()
{

	int numbers[200000];
	int sum,i,n;

	scanf("%d" , &n);

	for(i=1;i<n;i++)
	{
		if(n%i==0)
		{
			numbers[i-1]=i;
		}else
		{
			numbers[i-1]=0;
		}
	}

	sum = 0;
	for(i=0;i<n;i++)
	{	
		if(numbers[i]!=0)
		{
			sum = sum + numbers[i];
		}
	}

	if (sum != n)
	{
		printf("%s" , "NO");
	}

	if (sum == n)
	{
		printf("%s" , "YES");
	}

	return 0;
}