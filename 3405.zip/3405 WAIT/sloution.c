
#include <stdio.h>



int main()
{

	int numbers[1000] = {};
	int i,status = 1;
	int n,x,j,y,temp;

	while(status)
	{
		scanf("%d" , &n);
		numbers[i] = n;
		if(n == 0)
		{
			status = 0;
		}
		i = i + 1;
	}

	j = i;

	for(y=0;y < i;y++)
	{	
		temp = numbers[y];
		numbers[y] = numbers[i-1];
		numbers[i-1] = temp;
		i = i - 1 ;
	}

	for(x = 0;x < j ;x++) // n = 4 is final loop
	{
		if(numbers[x]!=0)
		{
			printf("%d\n", numbers[x] );
		}
	}
	return 0 ;
}
