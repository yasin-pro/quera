#include <stdio.h>

int main(){


	int n;

	scanf("%d" , &n);

	int i;
	int f;
	f = n;
	for(i=1;i!=n;i++)
	{
		f = f * (n - i);
	}
	printf("%d" , f);



	return 0;
}
