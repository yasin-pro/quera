
n = input()

print(f'saal:{n[:2]}')
print(f'maah:{n[2:]}')