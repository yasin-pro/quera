#include <stdio.h>

int main(){

	
	int k;

	scanf("%d" , &k);

	if(k%2==0)
	{
		printf("%s" , "Bala Barare");
	}else
	{
		printf("%s" , "Payin Barare");
	}

	return 0;
}
