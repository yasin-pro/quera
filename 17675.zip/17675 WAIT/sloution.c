#include <stdio.h>

// Main Function
int main()
{
	int fibonachi[10] = {

		1, 2, 3, 5, 8, 13, 21, 34, 55, 89
	
	};
	int i,j,n,status;

	scanf("%d" , &n);

	status = 0;
	for(i=1;i<n+1;i++)
	{

		status = 0;

		for(j=0;j<10;j++)
		{

			if(i==fibonachi[j])
			{
				status = 1;
				break;
			}

			status = 0;
		
		}

		if(status == 1)
		{
			printf("+");
		}else
		{
			printf("-");
		}
	
	
	}

	

	return 0;
}
