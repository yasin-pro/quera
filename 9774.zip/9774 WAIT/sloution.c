#include <stdio.h>
#include <cstring>

int main(){

	
	int y,x,z;
	char n[20];

	scanf("%s" , &n);

	for(y=0;y!=strlen(n);y++)
	{
		

		z = n[y];
		z = z - 48;
			
		printf("%c: " , n[y]);

		for(x=0;x!=z;x++)
		{
			printf("%c" , n[y]);
		}

		printf("\n");

	}

	return 0;
}
