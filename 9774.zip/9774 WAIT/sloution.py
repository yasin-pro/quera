

n = input()
for y in n:
    s = ''
    for x in range(int(y)):
        s += y
    print(f'{y}: {s}')
    