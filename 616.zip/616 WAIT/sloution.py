



n = int(input())
status = True
i = 0
while status:
	x = 2**i
	if x > n:
		print(x)
		status = False
	i+=1
