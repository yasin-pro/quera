#include <stdio.h>

int main(){

	int n;
	scanf("%d" , &n);

	int sum=1;
	while(1)
	{
		sum = sum * 2;
		if(sum > n)
		{
			printf("%d" , sum);
			break;
		}
	}



}
