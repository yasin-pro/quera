
#include <stdio.h>

// Main Function
int main()
{

	int i,a,b,l;
	int sum = 0;

	scanf("%d%d%d" , &a , &b , &l);

	for(i=1;i<=l;i++)
	{

		if(i%2==0)
		{

			sum=sum+b;


		}else
		{

			sum=sum+a;

		}

	}

	printf("%d",sum);

	return 0;
}