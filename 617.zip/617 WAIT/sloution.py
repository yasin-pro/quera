

n = input()
temp = n[::-1]
if n == temp:

    print('YES')
else:
    print('NO')