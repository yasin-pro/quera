
n = input()

for i in range(len(n)):

    print(f'{n[i]*len(n[:i])}{n[i:]}') 