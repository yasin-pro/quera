#include <stdio.h>

int main(){
	

	int n , y , x;

	scanf("%d" , &n);
	
	for(y=1;y!=n+1;y++)
	{
		
		for(x=1;x!=n+1;x++)
		{
			printf("%d " , x * y);
		}

		printf("\n");

	}
	

	return 0;
}
