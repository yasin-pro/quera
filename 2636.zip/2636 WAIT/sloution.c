#include <stdio.h>


// Main Function
int main()
{


	int s,v,r,f,a,p;

	scanf("%d%d%d%d%d%d" , &s , &v , &r , &f , &a , &p );

	printf("%d " , 1-s);
	printf("%d " , 1-v);
	printf("%d " , 2-r);
	printf("%d " , 2-f);
	printf("%d " , 2-a);
	printf("%d " , 8-p);


	return 0;
}