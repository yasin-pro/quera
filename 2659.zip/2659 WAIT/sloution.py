

input_len = int(input())
first = input()
seccond = input()
uncorrect = 0
for i in range(input_len):
    if first[i] != seccond[i]:
        uncorrect += 1
print(uncorrect)


