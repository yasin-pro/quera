#include <stdio.h>

int main(){

	int n ;

	scanf("%d" , &n);

	int myArray[1000] = {};

	int i ;

	int c = 0;

	while(c != n){

		scanf("%d" , &i);

		myArray[c] = i ;

		c = c + 1;

	}

	int x ;

	int t = 0;

	for(x = 0 ; x <= n-1 ; x = x + 1)
	{

		if(x == n-1)
		{

			break;
			
		}

		if(myArray[x] != myArray[x + 1])
		{

			t++;

		}
	}

	printf("%d" , t);


	return 0;
}
