

n = int(input())

l = []
c = 0
while c != n :

    l.append(input())

    c += 1

c = 0
for i , item in enumerate(l):

    if len(l) -1  == i:
        break

    if l[i] != l[i + 1]:
        c += 1

print(c)


