

weight = int(input())

height = float(input())

bmi = weight / (height * height)

print(f'{bmi:.2f}')
if bmi < 18.5 : 
    print('Underweight')
if 18.5 <= bmi < 25:
    print('Normal')
if 25 <= bmi < 30:
    print('Overweight')
if 30 <= bmi:
    print('Obese')