#include <stdio.h>

int main(){


	

	int d1 , d2 , d3;

	scanf("%d%d%d" , &d1 , &d2 , &d3);

	if(d1 + d2 + d3 != 180)
	{
		printf("%s" , "No");
	}else if(d1 + d2 + d3 == 180)
	{
		if((d1 == 0) || (d2 == 0) || (d3 == 0))
		{
			printf("%s" ,"No");
		}else
		{
			printf("%s" , "Yes");
		}
	}

	return 0;
}
