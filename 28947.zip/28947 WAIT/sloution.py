


n = int(input())

my_list = ['sib' , 'samanoo' , 'sabze' , 'serke' , 'sekke' , 'somagh' , 'senjed']

for i in range(n):

    print(my_list[i])