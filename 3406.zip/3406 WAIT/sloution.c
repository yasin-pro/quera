

#include <stdio.h>

// Main Function
int main()
{

	char f[100];
	char s[100];

	char first_yekan;
	char seccond_yekan;

	char first_dahgan;
	char seccond_dahgan;

	char first_sadgan;
	char seccond_sadgan;

	scanf("%s%s",&f,&s);

	//-------------------------------
	first_yekan =f[2]-48;
	seccond_yekan = s[2]-48;
	if(first_yekan > seccond_yekan)
	{
		printf("%s < %s" , s , f );
		return 0;
	}
	if(first_yekan < seccond_yekan)
	{
		printf("%s < %s" , f , s );
		return 0;
	}
	//-------------------------------
	
	//-------------------------------
	first_dahgan = f[1]-48;
	seccond_dahgan = s[1]-48;
	if(first_dahgan > seccond_dahgan)
	{
		printf("%s < %s" , s , f );
		return 0;

	}
	if(first_dahgan < seccond_dahgan)
	{
		printf("%s < %s" , f , s );
		return 0;

	}
	//-------------------------------

	//-------------------------------
	first_sadgan = f[0]-48;
	seccond_sadgan = s[0]-48;
	if(first_sadgan > seccond_sadgan)
	{
		printf("%s < %s" , s , f );
		return 0;	

	}
	if(first_sadgan < seccond_sadgan)
	{
		printf("%s < %s" , f , s );
		return 0;	

	}
	//-------------------------------


	printf("%s = %s" , s , f);


	return 0;
}