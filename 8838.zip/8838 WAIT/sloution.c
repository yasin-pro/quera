#include <stdio.h>


// Main Function
int main()
{


	int i,n;
	char s[100];

	scanf("%d%s" , &n , &s);


	for(i=0;i<n;i++)
	{
		printf("%s" , "copy of ");
	}

	printf("%s" , s);


	return 0;
}