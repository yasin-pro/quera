_ = input()

words_list = input().split(' ')

print(' '.join(words_list[::-1]))