#include <stdio.h>


int main(){

	int t;
	scanf("%d" , &t);

	if(t > 100)
	{
		printf("%s" ,"Steam" );

	}else if(t < 0)
	{
		printf("%s" , "Ice");
	}else
	{
		printf("%s" , "Water");
	}


	return 0;
}
